# Demo-CRUD
Proyecto Demo con Angular, Springboot, Java y MySQL

Referencia: https://www.youtube.com/watch?v=O13X14TGtm8

Contenido del repositorio:
  * Carpeta BackEnd: Proyecto en Java para las consultas con la base de datos por medio de frameworks.
  * Carpeta FrontEnd: Proyecto en Angular que realiza el consumo de servicios del BackEnd.




