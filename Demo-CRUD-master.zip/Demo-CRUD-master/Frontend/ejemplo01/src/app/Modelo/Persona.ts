export class Persona {
    id: number;
    name: String;
    apellidos: String;
}